var elemento =document.getElementById("div1");
elemento.innerHTML="<b>Cesar<b>";