let swLocation ="sw.js";

// en el primer if se indetifica si el navejador 

if(navigator.serviceWorker){
    // en le segundo if se identifica en que servidor 
    if(window.location.href.includes("localhost"))
        swLocation ="/sw.js";
        // registro de ubicacion
    navigator.serviceWorker.register(swLocation);
}